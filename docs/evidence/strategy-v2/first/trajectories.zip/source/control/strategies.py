"""Distinct bounded recovery maneuvers, selected by observable failure evidence."""
from collections import deque

import mujoco
import numpy as np

from agent.strategy_diagnostics import reversals
from control.recovery import RecoveryConfig, RecoveryController, checked_observation
from control.settled_recovery import ConfirmedFailureDetector, SettledRecoveryController
from control.strategy_schema import StrategySkill, parse_strategy, strategy_text


class StrategyController(SettledRecoveryController):
    def __init__(self, model, strategy=None):
        super().__init__(model)
        self.strategy = parse_strategy(strategy_text(strategy or StrategySkill()))
        self.config = RecoveryConfig(approach_timeout=100, phase_timeout=65, recovery_timeout=180)
        self.detector = ConfirmedFailureDetector(self.config, self.skill.stop_distance)
        self.stable = self.strategy.approach == 'stabilized'
        self.recent = deque(maxlen=20)
        self.previous_target = None
        self.command_target = None
        self.command_stage = 'approach'
        self.pending_plan = 'reapproach'
        self.snapshot_target = None
        self.repush_error = None
        self.arrival_count = 0
        self.strategy_events = []

    def _transition(self, phase):
        super()._transition(phase)
        self.arrival_count = 0

    def _arrived(self, tip, target, threshold=.04):
        self.arrival_count = self.arrival_count + 1 if np.linalg.norm(tip - target) < threshold else 0
        return self.arrival_count >= (3 if self.stable else 1)

    def _begin(self, reason, obs, force_plan=None):
        if self.retries >= 2:
            self._event('retry_budget_exhausted', 'exhausted')
            self._transition('exhausted')
            return
        self.retries += 1
        plan = force_plan or ('repush' if reason == 'stall' and self.strategy.stall == 'controlled_repush'
                  else 'correct' if reason in ('overshoot', 'goal_escape') and self.strategy.overshoot == 'reposition_correct'
                  else 'reapproach')
        if reason in ('lost_contact', 'contact_not_acquired') and self.strategy.contact == 'stabilized_reacquire':
            self.stable = True
        if self.strategy.approach == 'adaptive' and reason in ('approach_timeout', 'phase_timeout'):
            self.stable = True
        self.pending_plan = plan
        self.recovery_started = self.step
        self.recovery_anchor = obs[14:17].copy()
        self.snapshot_target = None
        self.detector.reset()
        phase = 'repush_backoff' if plan == 'repush' else 'stabilize'
        self._event(reason, phase)
        if len(self.strategy_events) < 12:
            self.strategy_events.append({'step': self.step, 'reason': reason, 'strategy': plan,
                                         'stabilized_tracking': self.stable})
        self._transition(phase)
        self.repush_error = float(np.linalg.norm(obs[17:19] - obs[20:22]))

    def _record_target(self, target, stage):
        self.command_stage = stage
        self.command_target = target.copy() if target is not None else None
        self.previous_target = self.command_target
        return target

    def target(self, observation):
        obs = checked_observation(observation)
        self.step += 1
        tip, obj, goal = obs[14:17], obs[17:20], obs[20:23]
        delta = goal[:2] - obj[:2]
        error = float(np.linalg.norm(delta))
        direction = delta / max(error, 1e-9)
        behind = obj.copy()
        behind[:2] -= self.skill.approach_offset * direction
        raised = behind.copy()
        raised[2] = self.skill.approach_height
        if self.previous_target is not None:
            self.recent.append((float(np.linalg.norm(tip - self.previous_target)), obs[7:14].copy()))
        if (not self.stable and self.strategy.approach == 'adaptive' and len(self.recent) == 20
                and self.phase in ('approach', 'lower', 'recover_lift', 'reposition', 'correct_lower')):
            distances = [item[0] for item in self.recent]
            if (np.median(distances) > .08 and distances[0] - distances[-1] < .025
                    and reversals([item[1] for item in self.recent], .1) > .08):
                self.stable = True
                self._event('observed_tracking_oscillation', self.phase)
        recovery_phases = ('stabilize', 'recover_lift', 'reposition', 'correct_lower', 'repush_backoff', 'repush', 'correct_push')
        age = self.step - self.phase_started
        if self.phase in ('approach', 'lower') and age >= self.config.approach_timeout:
            self._begin('approach_timeout', obs)
        elif self.phase in recovery_phases:
            if self.step - self.recovery_started >= self.config.recovery_timeout:
                self._begin('recovery_timeout', obs, 'reapproach')
            elif age >= self.config.phase_timeout:
                self._begin('phase_timeout', obs, 'reapproach')

        if self.phase in ('push', 'hold', 'correct_push'):
            reason = self.detector.update(obs)
            if reason:
                self._begin(reason, obs)
            elif error <= self.skill.stop_distance:
                if self.phase != 'hold':
                    self.hold_target = tip.copy()
                    self._transition('hold')
            elif self.phase == 'hold':
                self._begin('goal_escape', obs)

        stage = self.phase
        target = None
        if stage == 'exhausted':
            return self._record_target(None, stage), direction
        if stage == 'hold':
            target = self.hold_target.copy()
        elif stage == 'stabilize':
            target = self.recovery_anchor.copy()
            # Wait a fixed bounded interval instead of chasing a moving target.
            if self.step - self.phase_started >= 12:
                self._transition('recover_lift')
        elif stage == 'recover_lift':
            target = self.recovery_anchor.copy()
            target[2] = self.skill.approach_height
            if self._arrived(tip, target):
                self.snapshot_target = raised.copy()  # recompute side AFTER lift
                self._transition('reposition')
        elif stage == 'reposition':
            target = self.snapshot_target.copy()
            if self._arrived(tip, target):
                self._transition('correct_lower')
        elif stage == 'correct_lower':
            target = behind.copy()
            if self._arrived(tip, target, .05):
                self.detector.reset()
                self._transition('correct_push' if self.pending_plan == 'correct' else 'push')
        elif stage in ('approach', 'lower'):
            target = raised if stage == 'approach' else behind
            if self._arrived(tip, target, .04 if stage == 'approach' else .05):
                self._transition('lower' if stage == 'approach' else 'push')
                self.detector.reset()
        elif stage == 'repush_backoff':
            target = obj.copy()
            target[:2] -= .07 * direction
            if self._arrived(tip, target, .025):
                self._transition('repush')
        else:
            target = obj.copy()
            target[:2] -= (.015 if stage == 'repush' else .035 if stage == 'correct_push' else self.skill.push_offset) * direction
            if stage == 'repush':
                if error <= self.skill.stop_distance or self.repush_error - error >= .012:
                    self._transition('push')
                    self.detector.reset()
                elif self.step - self.phase_started >= 40:
                    self._begin('repush_no_progress', obs, 'reapproach')
                    target = self.recovery_anchor.copy() if self.phase != 'exhausted' else None
                    stage = self.phase
            if stage in ('repush', 'correct_push') and target is not None:
                # Bounded Cartesian progress replaces an unbounded target jump.
                displacement = target - tip
                target = tip + displacement * min(1., .008 / max(np.linalg.norm(displacement), 1e-9))
        return self._record_target(target, stage), direction

    def action(self, observation):
        obs = checked_observation(observation)
        direct = RecoveryController.action(self, obs)  # one target/phase update
        if not self.stable:
            return direct
        velocity = np.clip(2 * (self.reference - obs[:7]), -.8, .8)
        if self.command_stage in ('stabilize', 'exhausted'):
            velocity[:] = 0
        acceleration = np.clip((velocity - obs[7:14]) / .4, -2., 2.)
        self.dynamics.qpos[:7] = obs[:7]
        self.dynamics.qvel[:] = 0
        self.dynamics.qvel[:7] = obs[7:14]
        mujoco.mj_forward(self.model, self.dynamics)
        mujoco.mj_fullM(self.model, self.dynamics, self.mass_matrix)
        torque = self.mass_matrix[:7, :7] @ acceleration + self.dynamics.qfrc_bias[:7] - self.dynamics.qfrc_passive[:7]
        self.previous_action = np.clip(torque, -self.skill.max_torque, self.skill.max_torque)
        return self.previous_action.copy()

    def diagnostics(self):
        result = super().diagnostics()
        result.update(policy='developer_distinct_strategies_v2', strategy=strategy_text(self.strategy),
                      strategy_events=list(self.strategy_events), stabilized_tracking=self.stable)
        return result
